﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int intList = rand.Next(0, 1001);
            int i = 0;
            int guess = int.Parse(Console.ReadLine());
            while (guess != intList && guess != -1)
            {
                i++;
                Console.WriteLine("What is your number?");
                Console.WriteLine("Press -1 to give up");
                guess = int.Parse(Console.ReadLine());
                int[] numb = new int[6];
                if (guess > intList)
                {
                    Console.WriteLine("too high.");
                }
                else if (guess < intList)
                {
                    Console.WriteLine("too low");
                }
                else if (guess == intList)
                {
                    Console.WriteLine("correct");
                }
                Console.WriteLine("You guessed " + i + " times");
            }
            if (guess == -1)
            {
                Console.WriteLine("You loose. The number was" + intList);
            }
            else
            {
                Console.WriteLine("You win! You guessed the number in" + i + " guesses");
            }
            Console.ReadKey();
        }
    }
}
